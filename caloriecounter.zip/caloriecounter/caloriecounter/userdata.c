#include <errno.h>

#include <fcntl.h>

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <sys/stat.h>

#include <sys/types.h>

#include <time.h>



#include "userdata.h"



#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)

#define WINDOWS

#endif

#ifdef WINDOWS

#define SLASH '\\'

#define DATAFILEPATH "\\AppData\\Local\\calorieclock\\userdata"

#define FMT_LL " %I64d"

#define FMT_LL_NOSPC "%I64d"

#define mkdir(A, B) mkdir(A)

#else

#define SLASH '/'

#define DATAFILEPATH "/.config/calorieclock/userdata"

#define FMT_LL " %lld"

#define FMT_LL_NOSPC "%lld"

#endif


#define ENTRYCOUNT (4095)

static struct userdata userdata[ENTRYCOUNT + 1] = {};

static struct userdata working_userdata = {};


static const char *userhomepath(void) {

	static const char *retval = 0;

	if (!retval) retval = getenv(

#ifdef WINDOWS

		"USERPROFILE"

#else

		"HOME"

#endif

		);

	return retval;

}


static void ensure_exists(const char *path) {

	struct stat dontcare; 

	char parentpath[strlen(path) + 1];

	strcpy(parentpath, path);

	for (size_t i = 0; parentpath[i]; ++i) { 
		if (parentpath[i] == SLASH && i != 0

#ifdef WINDOWS

			&& parentpath[i - 1] != ':'

#endif

			) { 

			parentpath[i] = 0; 
			if (!!stat(parentpath, &dontcare)) 

				if (mkdir(parentpath,

					S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH) == -1) // try to mkdir it

					fprintf(stderr, 
						"WARN: Unable to create the config directory '%s': "

						"errno %d\n",

						parentpath, errno);

			parentpath[i] = SLASH; 
		}

	}

	if (!!stat(path, &dontcare)) { 

		int fd = open(path, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);

		if (fd == -1) { 

			fprintf(stderr,

				"ERROR: Unable to create the userdata file '%s': "

				"errno %d\n",

				parentpath, errno);

			exit(errno);

		}
		else close(fd);

	}

}



static void dopathfunc(void(*pathfunc)(const char *)) {

	const char *home = userhomepath(); 
	size_t homelen = strlen(home);

	size_t fnamelen = strlen(DATAFILEPATH);

	char path[homelen + fnamelen + 1]; 

	strcpy(&path[0], home); 

	strcpy(&path[homelen], DATAFILEPATH);

	ensure_exists(path);

	pathfunc(path);

}

static void commit_userdata_notimestamp(void) {

	for (size_t i = ENTRYCOUNT - 1; i > 0; --i)

		userdata[i] = userdata[i - 1]; 
	userdata[0] = working_userdata; 

}



static void load_userdata_frompath(const char *path) {

	FILE *fin = fopen(path, "r"); 

	if (!fin) { 
		fprintf(stderr,

			"ERROR: Unable to open the userdata file '%s' for reading: "

			"errno %d\n",

			path, errno);

		exit(errno);

	}

	char line[4096];

	while (fgets(line, sizeof(line), fin)) 

		if (sscanf(line, "%lf %lf %lf %lf %lf %lf %lf %lf" FMT_LL FMT_LL " %d",

			&working_userdata.calorieallowance, 

			&working_userdata.weight,

			&working_userdata.height,

			&working_userdata.gendar,

			&working_userdata.activitylevel,

			&working_userdata.percentbodyfat,

			&working_userdata.tdee,

			&working_userdata.goalweeklydelta,

			&working_userdata.dateofbirth,

			&working_userdata.lastupdate,

			&working_userdata.useimperialunits))

			commit_userdata_notimestamp();
	fclose(fin);

}



static void save_userdata_topath(const char *path) {

	FILE *fout = fopen(path, "w"); 
	if (!fout) { 

		fprintf(stderr,

			"ERROR: Unable to open the userdata file '%s' for writing: "

			"errno %d\n",

			path, errno);

		exit(errno);

	}

	size_t i; 
	for (i = ENTRYCOUNT - 1; i != ((size_t)-1) && !userdata[i].lastupdate; --i);

	for (; i != ((size_t)-1); --i)

		fprintf(fout, "%lf %lf %lf %lf %lf %lf %lf %lf" FMT_LL FMT_LL " %d\n",

			userdata[i].calorieallowance, 
			userdata[i].weight,

			userdata[i].height,

			userdata[i].gendar,

			userdata[i].activitylevel,

			userdata[i].percentbodyfat,

			userdata[i].tdee,

			userdata[i].goalweeklydelta,

			userdata[i].dateofbirth,

			userdata[i].lastupdate,

			userdata[i].useimperialunits);

	fclose(fout);

}



void load_userdata(void) {

	dopathfunc(load_userdata_frompath);

}



struct userdata *get_userdata(void) {

	working_userdata = userdata[0]; 
	return &working_userdata;
}



void commit_userdata(void) {
 working_userdata.lastupdate = time(0);

	commit_userdata_notimestamp();

}


void save_userdata(void) {

	dopathfunc(save_userdata_topath);

}


const struct userdata *get_all_userdata(void) {

	return userdata;

}

const char *my_lltoa(long long int ll) {

	static char retval[21] = {}; 

	snprintf(retval, sizeof(retval), FMT_LL_NOSPC, ll);

	return retval;

}


static void fresh_start_frompath(const char *path) {

	size_t pathlen = strlen(path);

	char newpath[pathlen + 30]; 
	strcpy(newpath, path);

	strcpy(&newpath[pathlen], "-archive-");

	strcpy(&newpath[pathlen + 9], my_lltoa(time(0)));

	if (rename(path, newpath) == -1) { 

		fprintf(stderr,

			"WARN: Unable to rename file '%s' to '%s': "

			"errno %d\n"

			"Since your progress could not be archived, it was not cleared.\n",

			path, newpath, errno);

	}
	else {

		memset(userdata, 0, sizeof(userdata));

		get_userdata();

	}

}

void fresh_start(void) {

	dopathfunc(fresh_start_frompath);

}