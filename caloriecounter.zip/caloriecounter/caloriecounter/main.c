#include <ctype.h>

#include <stdio.h>

#include "shell.h"

#include "userdata.h"

int main(int argc, char *argv[]) {

	load_userdata();

	if (argc >= 2) respond(argv[1], argc - 2, &argv[2], 1);

	else {

		shellinit();

		printf("cc) ");

		for (char line[4096]; fgets(line, 4096, stdin); printf("cc) ")) {

			if (*line && *line != '\n') {

				char *marker = line;

				while (isspace(*marker)) ++marker;

				int wordcount = *marker && 1;

				for (; *marker; ++marker)

					if (isspace(*marker)) {

						while (isspace(*marker)) ++marker;

						if (*marker) ++wordcount;

						--marker;

					}

				char *words[wordcount];

				size_t i = 0;

				marker = line;

				while (isspace(*marker)) ++marker;

				for (; *marker; ++marker)

					if (isspace(*marker)) {

						*marker++ = 0;

						while (isspace(*marker)) ++marker;

						--marker;

					}
					else {

						words[i++] = marker;

						while (!isspace(*marker) && *marker) ++marker;

						--marker;

					}

					checkunits();

					respond(words[0], wordcount - 1, &words[1], 0);

			}

		}

	}

	puts("");

	save_userdata();

	return 0;

}