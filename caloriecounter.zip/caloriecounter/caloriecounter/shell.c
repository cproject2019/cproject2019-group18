#include <stdio.h>

#include <ctype.h>

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include "logic.h"

#include "shell.h"

#include "userdata.h"

#define VERSION "0.1.0"

#define AUTHOR "Jaime McCann"

#define DATE "12/22/2018"

#define SECONDS_IN_YEAR (31557600.0)

#define SECONDS_IN_DAY (84600.0)

#define SECONDS_IN_WEEK (604800.0)

#define SECONDS_IN_MONTH (2629800.0)

#define SECONDS_IN_HOUR (3600.0)

#define SECONDS_IN_MINUTE (60.0)

#define CALORIES_IN_KG (7716.17)

static int units = 0;

static const char *wgtunit[] = { "kg", "lbs" };

static const char *hgtunit[] = { "cm", "\"" };

static const double wgtmult[] = { 1.0, 2.20462 };

static const double hgtmult[] = { 1.0, 2.54 };

static double promptnum(void) {

	char line[4096];

	double retval;

	for (;;) {

		printf("> ");

		if (!fgets(line, 4096, stdin)) exit(0);

		char *marker = line;

		while (isspace(*marker)) ++marker;

		if (sscanf(marker, "%lf", &retval)) return retval;

		puts("(Please enter a numeric value.)");

	}

}

static double promptnum_soft(double fallback) {

	char line[4096];

	double retval;

	for (;;) {

		printf("> ");

		if (!fgets(line, 4096, stdin)) exit(0);

		char *marker = line;

		while (isspace(*marker)) ++marker;

		if (!*marker) {

			if (fallback) printf("(Assuming %lf.)\n", fallback);

			return fallback;

		}

		if (sscanf(marker, "%lf", &retval)) return retval;

		puts("(Please enter a numeric value or a blank line.)");

	}

}

static int promptyn(void) {

	char line[4096];

	for (;;) {

		printf("[y/n]> ");

		if (!fgets(line, 4096, stdin)) exit(0);

		char *marker = line;

		while (isspace(*marker)) ++marker;

		if (*marker == 'y' || *marker == 'Y') return 1;

		if (*marker == 'n' || *marker == 'N') return 0;

		puts("(Please enter Y for yes or N for no.)");

	}

}

static int promptYn(void) {

	char line[4096];

	for (;;) {

		printf("[Y/n]> ");

		if (!fgets(line, 4096, stdin)) exit(0);

		char *marker = line;

		while (isspace(*marker)) ++marker;

		if (*marker == 'y' || *marker == 'Y' || !*marker) return 1;

		if (*marker == 'n' || *marker == 'N') return 0;

		puts("(Please enter Y or a blank line for yes, or N for no.)");

	}

}

static int promptyN(void) {

	char line[4096];

	for (;;) {

		printf("[y/N]> ");

		if (!fgets(line, 4096, stdin)) exit(0);

		char *marker = line;

		while (isspace(*marker)) ++marker;

		if (*marker == 'y' || *marker == 'Y') return 1;

		if (*marker == 'n' || *marker == 'N' || !*marker) return 0;

		puts("(Please enter Y for yes, or N or a blank line for no.)");

	}

}

static int promptchoice(const char *chars) {

	if (!*chars) return -1;

	char line[4096];

	for (;;) {

		printf("[%c", *chars);

		for (size_t i = 1; chars[i]; ++i)

			printf("/%c", chars[i]);

		printf("]> ");

		if (!fgets(line, 4096, stdin)) exit(0);

		char *marker = line;

		while (isspace(*marker)) ++marker;

		for (size_t i = 0; chars[i]; ++i)

			if (tolower(chars[i]) == tolower(*marker))

				return chars[i];

		printf("(Please enter any of the following: %c", *chars);

		for (size_t i = 1; chars[i]; ++i)

			printf(", %c", chars[i]);

		puts(".)");

	}

}

static int promptchoice_soft(const char *chars) {

	if (!*chars) return -1;

	char line[4096];

	for (;;) {

		printf("[%c", *chars);

		for (size_t i = 1; chars[i]; ++i)

			printf("/%c", chars[i]);

		printf("]> ");

		if (!fgets(line, 4096, stdin)) exit(0);

		char *marker = line;

		while (isspace(*marker)) ++marker;

		if (!*marker) return *chars;

		for (size_t i = 0; chars[i]; ++i)

			if (tolower(chars[i]) == tolower(*marker))

				return chars[i];

		printf("(Please enter any of the following: %c", *chars);

		for (size_t i = 1; chars[i]; ++i)

			printf(", %c", chars[i]);

		printf(". Alternatively, enter a blank line for %c.)\n", *chars);

	}

}

void shellinit(void) {

	puts("calorieclock v" VERSION "\n"

		DATE " " AUTHOR);

	if (!(get_all_userdata()->lastupdate)) {

		double weight = 0;

		double height = 0;

		double gendar = 0;

		double activitylevel = 0;

		double percentbodyfat = 0;

		double tdee = 0;

		double goalweeklydelta = 0;

		time_t dateofbirth = 0;

		puts("===INITIAL QUESTIONNAIRE===");

		puts("Do you want to use imperial units "

			"(lbs and inches rather than kg and cm)?");

		if (promptyN()) units = 1;

		puts("Do you know your TDEE?");

		if (promptyN()) {

			puts("Please enter it: ____ cals/day");

			tdee = promptnum_soft(2000);

		}
		else {

			puts("Do you know your percent body fat?");

			if (promptyN()) {

				puts("Please enter it: __%%");

				percentbodyfat = promptnum_soft(12) / 100;

				if (percentbodyfat > 100) percentbodyfat = 100;

				if (percentbodyfat < 0) percentbodyfat = 0;

			}

			printf("Weight: ___%s\n", wgtunit[units]);

			weight = promptnum_soft(0) / wgtmult[units];

			if (!percentbodyfat) {

				printf("Height: ___%s\n", hgtunit[units]);

				height = promptnum_soft(0) / hgtmult[units];

				if (height < 0) height = 0;

				printf("Biological sex?\n");

				sexfactor = (promptchoice("mf") == 'm');

				puts("Are you currently undergoing hormone replacement therapy "

					"to help you transition into a non-cisgender identity?");

				if (promptyN()) {

					puts("On a scale of 0 to 100, "

						"0 being no effect and 100 being full physiological transition, "

						"how much would you say the hormone treatment "

						"has affected your body composition and metabolism thus far?");

					double howmuch = promptnum_soft(0);

					if (howmuch > 100) howmuch = 100;

					if (howmuch < 0) howmuch = 0;

					if (sexfactor) sexfactor = (100 - howmuch) / 100;

					else gendar = howmuch / 100;

				}

				puts("Activity level?\n"

					"S: sedentary (little to no exercise)\n"

					"L: lightly active (light exercise 1-3 days/wk)\n"

					"M: moderately active (moderate exercise 3-5 days/wk)\n"

					"V: very active (hard exercise 6-7 days/wk)\n"

					"E: extra active (very hard exercise & physical job or 2x training)");

				switch (promptchoice_soft("SLMVE")) {

				case 'S': activitylevel = 1.2; break;

				case 'L': activitylevel = 1.375; break;

				case 'M': activitylevel = 1.55; break;

				case 'V': activitylevel = 1.725; break;

				case 'E': activitylevel = 1.9;

				}

				puts("Birth year?");

				int birthyear = promptnum_soft(0);

				if (birthyear < 0) birthyear = 0;

				if (birthyear) {

					puts("Birth month? [1 - 12]");

					int birthmonth = promptnum_soft(1);

					if (birthmonth < 1) birthmonth = 1;

					if (birthmonth > 12) birthmonth = 12;

					puts("Day you were born in the month? [1 - 31]");

					int birthmonthday = promptnum_soft(1);

					if (birthmonthday < 1) birthmonthday = 1;

					if (birthmonthday > 31) birthmonthday = 31;

					dateofbirth =

						SECONDS_IN_YEAR*(birthyear - 1970)

						+ SECONDS_IN_DAY*(365.25 / 12 * (birthmonth - 1)

							+ birthmonthday - 1);

				}

			}

		}

		printf("Weekly weight loss goal? __%s\n", wgtunit[units]);

		goalweeklydelta = promptnum_soft(1) / wgtmult[units];

		if (tdee) do_initial_setup_known_tdee(tdee, goalweeklydelta);

		else {

			do_initial_setup(

				weight,

				height,

				gendar,

				activitylevel,

				percentbodyfat,

				goalweeklydelta,

				dateofbirth);

			printf("Your TDEE is around %d cals/day.\n",

				(int)(get_userdata()->tdee));

			get_userdata()->useimperialunits = units;

			commit_userdata();

		}

		puts("User data initialized.\n===END OF INITIAL QUESTIONNAIRE===");

	}

	puts("For a list of commands, enter the word 'help' at any time.");

}

void checkunits(void) {

	units = get_userdata()->useimperialunits;

}

static const char *timewithunit(int seconds) {

	static char retval[256];

	if (seconds > SECONDS_IN_YEAR)

		sprintf(retval, "%.2lf years", seconds / SECONDS_IN_YEAR);

	else if (seconds > SECONDS_IN_MONTH)

		sprintf(retval, "%.2lf months", seconds / SECONDS_IN_MONTH);

	else if (seconds > SECONDS_IN_WEEK)

		sprintf(retval, "%.2lf weeks", seconds / SECONDS_IN_WEEK);

	else if (seconds > SECONDS_IN_DAY)

		sprintf(retval, "%.2lf days", seconds / SECONDS_IN_DAY);

	else if (seconds > SECONDS_IN_HOUR)

		sprintf(retval, "%.2lf hours", seconds / SECONDS_IN_HOUR);

	else if (seconds > SECONDS_IN_MINUTE)

		sprintf(retval, "%.2lf minutes", seconds / SECONDS_IN_MINUTE);

	else sprintf(retval, "%d seconds", seconds);

	return retval;

}

static void cmd_help(char *argv[], int quiet);

static void cmd_help1(char *argv[], int quiet);

static int time_until_cals(double want, double cals, struct userdata *userdata) {

	return (want - cals)*SECONDS_IN_DAY

		/ (userdata->tdee - userdata->goalweeklydelta*CALORIES_IN_KG / 7);

}

static void cmd_check(char *argv[], int quiet) {

	double cals = update_justcheckingcalories();

	if (quiet) printf("%.2lf\n", cals);

	else {

		if (cals < 0) printf(

			"You're behind on your weight loss goal by %.2lf calories. "

			"You'll have to wait %s before you're in the clear.\n",

			-cals, timewithunit(time_until_cals(0, cals, get_userdata())));

		else printf(

			"You're ahead of your weight loss goal by %.2lf calories.\n",

			cals);

		puts("For number of seconds until you can afford a particular meal size, "

			"try adding the desired number of calories to the end of the 'check' command "

			"(see 'help check').");

	}

}

static void cmd_check1(char *argv[], int quiet) {

	double cals = update_justcheckingcalories();

	double want = 500;

	sscanf(argv[0], "%lf", &want);

	int waittime = time_until_cals(want, cals, get_userdata());

	if (quiet) printf("%d\n", waittime);

	else if (waittime > 0)

		printf("It will be %s before you can afford to eat %.2lf calories.\n",

			timewithunit(waittime), want);

	else printf("You have been able to afford to eat %.2lf calories for the past %s.\n",

		want, timewithunit(-waittime));

}

static void cmd_log(char *argv[], int quiet) {

	puts("Did you consume or burn calories?\n"

		"C: consume\n"

		"B: burn");

	double cals;

	switch (promptchoice_soft("CB")) {

	case 'C': {

		puts("How many calories did you consume?");

		cals = promptnum_soft(0);

	} break;

	case 'B': {

		puts("How many calories did you burn?");

		cals = -promptnum_soft(0);

	}

	}

	if (cals) {

		log_calories(cals);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_log1(char *argv[], int quiet) {

	double cals = 0;

	sscanf(argv[0], "%lf", &cals);

	if (cals) {

		log_calories(cals);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_weight(char *argv[], int quiet) {

	double weight = get_userdata()->weight;

	if (quiet) printf("%.2lf\n", wgtmult[units] * weight);

	else {

		if (weight)

			printf("You last weighed in at %.2lf%s.\n",

				wgtmult[units] * weight, wgtunit[units]);

		else puts("No recorded weight.");

		puts("Weigh in now?");

		if (promptyN()) {

			printf("New weight: ___%s\n", wgtunit[units]);

			weight = promptnum_soft(0);

			if (weight < 0) weight = 0;

			if (weight) {

				update_weight(weight / wgtmult[units]);

				puts("Logged");

			}
			else puts("Abort");

		}

	}

}

static void cmd_weight1(char *argv[], int quiet) {

	double weight = 0;

	sscanf(argv[0], "%lf", &weight);

	if (weight < 0) weight = 0;

	if (weight) {

		update_weight(weight / wgtmult[units]);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_height(char *argv[], int quiet) {

	double height = get_userdata()->height;

	if (quiet) printf("%.2lf\n", hgtmult[units] * height);

	else {

		if (height)

			printf("Your last recorded height was %.2lf%s.\n",

				hgtmult[units] * height, hgtunit[units]);

		else puts("No recorded height.");

		puts("Record height now?");

		if (promptyN()) {

			printf("New height: ___%s\n", hgtunit[units]);

			height = promptnum_soft(0);

			if (height < 0) height = 0;

			if (height) {

				update_height(height / hgtmult[units]);

				puts("Logged");

			}
			else puts("Abort");

		}

	}

}

static void cmd_height1(char *argv[], int quiet) {

	double height = 0;

	sscanf(argv[0], "%lf", &height);

	if (height < 0) height = 0;

	if (height) {

		update_height(height / hgtmult[units]);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_sex(char *argv[], int quiet) {

	double sex = get_userdata()->gendar;

	if (quiet) printf("%.2lf\n", sex);

	else {

		if (sex)

			printf("Your last recorded sex multiplier was %.2lf.\n",

				sex);

		else puts("No recorded sex multiplier.");

		puts("Record sex multiplier now?");

		if (promptyN()) {

			printf("New sex multiplier: ___\n");

			sex = promptnum_soft(0);

			if (sex > 1) sex = 1;

			if (sex < 0) sex = 0;

			if (sex) {

				update_gendar(sex);

				puts("Logged");

			}
			else puts("Abort");

		}

	}

}

static void cmd_sex1(char *argv[], int quiet) {

	double sex = 0;

	sscanf(argv[0], "%lf", &sex);

	if (sex < 0) sex = 0;

	if (sex > 1) sex = 1;

	if (sex) {

		update_gendar(sex);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_activity(char *argv[], int quiet) {

	double activitylevel = get_userdata()->activitylevel;

	if (quiet) printf("%.2lf\n", activitylevel);

	else {

		if (activitylevel)

			printf("Your last recorded activity level was %.2lf.\n",

				activitylevel);

		else puts("No recorded activity level.");

		puts("Record activity level now?");

		if (promptyN()) {

			printf("New activity level: ___\n");

			activitylevel = promptnum_soft(0);

			if (activitylevel > 2) activitylevel = 2;

			if (activitylevel && activitylevel < 1) activitylevel = 1;

			if (activitylevel) {

				update_activitylevel(activitylevel);

				puts("Logged");

			}
			else puts("Abort");

		}

	}

}

static void cmd_activity1(char *argv[], int quiet) {

	double activitylevel = 0;

	sscanf(argv[0], "%lf", &activitylevel);

	if (activitylevel > 2) activitylevel = 2;

	if (activitylevel < 1 && activitylevel) activitylevel = 1;

	if (activitylevel) {

		update_activitylevel(activitylevel);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_pbf(char *argv[], int quiet) {

	double pbf = get_userdata()->percentbodyfat;

	if (quiet) printf("%.2lf\n", pbf);

	else {

		if (pbf)

			printf("Your last recorded percent body fat was %.2lf%%.\n",

				pbf * 100);

		else puts("No recorded percent body fat.");

		puts("Record percent body fat now?");

		if (promptyN()) {

			puts("New percent body fat: ___%");

			pbf = promptnum_soft(0) / 100;

			if (pbf > 1) pbf = 1;

			if (pbf < 0) pbf = 0;

			if (pbf) {

				update_percentbodyfat(pbf);

				puts("Logged");

			}
			else puts("Abort");

		}

	}

}

static void cmd_pbf1(char *argv[], int quiet) {

	double pbf = 0;

	sscanf(argv[0], "%lf", &pbf);

	pbf /= 100;

	if (pbf > 1) pbf = 1;

	if (pbf < 0) pbf = 0;

	if (pbf) {

		update_percentbodyfat(pbf);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_tdee(char *argv[], int quiet) {

	double tdee = get_userdata()->tdee;

	if (quiet) printf("%.2lf\n", tdee);

	else {

		if (tdee)

			printf("Your last recorded TDEE was %.2lf.\n",

				tdee);

		else puts("No recorded TDEE.");

		puts("Record TDEE now?");

		if (promptyN()) {

			puts("New TDEE: ___ cals/day\n");

			tdee = promptnum_soft(0);

			if (tdee < 0) tdee = 0;

			if (tdee) {

				update_tdee(tdee);

				puts("Logged");

			}
			else puts("Abort");

		}

	}

}

static void cmd_tdee1(char *argv[], int quiet) {

	double tdee = 0;

	sscanf(argv[0], "%lf", &tdee);

	if (tdee < 0) tdee = 0;

	if (tdee) {

		update_tdee(tdee);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_goal(char *argv[], int quiet) {

	double goal = get_userdata()->goalweeklydelta;

	if (quiet) printf("%.2lf\n", goal*wgtmult[units]);

	else {

		if (goal)

			printf("Your last recorded weekly weight loss goal was %.2lf %s/wk.\n",

				goal*wgtmult[units], wgtunit[units]);

		else puts("No recorded weekly weight loss goal.");

		puts("Record weekly weight loss goal now?");

		if (promptyN()) {

			printf("New weekly weight loss goal: ___ %s/wk\n",

				wgtunit[units]);

			goal = promptnum_soft(0) / wgtmult[units];

			if (goal < 0) goal = 0;

			if (goal) {

				update_goalweeklydelta(goal);

				puts("Logged");

			}
			else puts("Abort");

		}

	}

}

static void cmd_goal1(char *argv[], int quiet) {

	double goal = 0;

	sscanf(argv[0], "%lf", &goal);

	goal /= wgtmult[units];

	if (goal < 0) goal = 0;

	if (goal) {

		update_goalweeklydelta(goal);

		if (!quiet) puts("Logged");

	}
	else if (!quiet) puts("Abort");

}

static void cmd_units(char *argv[], int quiet) {

	if (quiet && units) puts("imperial");

	else if (quiet) puts("metric");

	else if (units) puts("Currently using the imperial unit system (lbs, inches).");

	else puts("Currently using the metric unit system (kg, cm).");

	if (!quiet) {

		puts("Swap unit system?");

		if (promptyN()) {

			units = 1 - units;

			get_userdata()->useimperialunits = units;

			commit_userdata();

			puts("Logged");

		}

	}

}

static void cmd_units1(char *argv[], int quiet) {

	if (!strcmp(argv[0], "metric")) {

		units = 0;

		get_userdata()->useimperialunits = units;

		commit_userdata();

		if (!quiet) puts("Switched to the metric system.");

	}
	else if (!strcmp(argv[0], "imperial")) {

		units = 1;

		get_userdata()->useimperialunits = units;

		commit_userdata();

		if (!quiet) puts("Switched to the imperial system.");

	}
	else if (!quiet)

		fputs("Unknown unit system, please use 'metric' or 'imperial'.",

			stderr);

	else fputs("unknown unit system", stderr);

}

static void cmd_progress(char *argv[], int quiet) {

	const struct userdata *all_userdata = get_all_userdata();

	double initialweight = 0;

	size_t i;

	for (i = 0; all_userdata[i].weight; ++i);

	if (i > 0) initialweight = all_userdata[--i].weight;

	double delta = initialweight - get_userdata()->weight;

	if (quiet) printf("%.2lf\n", delta*wgtmult[units]);

	else if (delta > 0)

		printf("You've lost %.2lf%s overall.\n",

			delta*wgtmult[units], wgtunit[units]);

	else printf("You've gained %.2lf%s overall.\n",

		-delta*wgtmult[units], wgtunit[units]);

}

static void cmd_save(char *argv[], int quiet) {

	save_userdata();

	if (!quiet) puts("Done");

}

static void cmd_abort(char *argv[], int quiet) {

	exit(0);

}

static void cmd_exit(char *argv[], int quiet) {

	save_userdata();

	exit(0);

}

static void cmd_reset(char *argv[], int quiet) {

	fresh_start();

	exit(0);

}

struct command {

	const char *name;

	int argc;

	void(*implementation)(char *argv[], int quiet);

	const char *summary;

	const char *documentation;

} static const commands[] = {

	{ "help", 1, cmd_help1,

	"List commands or get info (try 'help help')",

	"This command lists all commands "

	"available to you through the main calorieclock prompt. "

	"If you fill in the blank with the name of a command, "

	"you can get more detailed information on it." },

	{ "help", 0, cmd_help, 0, 0 },

	{ "check", 1, cmd_check1,

	"Check how many calories you have available",

	"Shows you how many calories you can safely eat right now "

	"without temporarily falling short of your weight loss goal. "

	"You'll see best results if you keep this number positive. "

	"If you fill in the blank with a number of calories, "

	"you can find out how long until you can eat that much." },

	{ "check", 0, cmd_check, 0, 0 },

	{ "log", 1, cmd_log1,

	"Log calories consumed or burned",

	"Fill in the blank with a number of calories. "

	"If positive, it will be logged as food; if negative, exercise." },

	{ "log", 0, cmd_log, 0, 0 },

	{ "weight", 1, cmd_weight1,

	"Show current weight or log a change in weight",

	"Shows you your last recorded weight. "

	"If you fill in the blank, it will instead record a new weight. "

	"In such case, your TDEE will then be recalculated, "

	"based on your rate of weight change as compared to your caloric intake "

	"if at least a week's worth of data is available for such analysis, "

	"or based on your new body stats otherwise. "

	"Enter the number without units. The preferred units will be used automatically. "

	"For information on viewing or changing the preferred units, see 'help units'." },

	{ "weight", 0, cmd_weight, 0, 0 },

	{ "height", 1, cmd_height1,

	"Show current height or log a change in height",

	"Shows you your last recorded height. "

	"If you fill in the blank, it will instead record a new height. "

	"In such case, your TDEE will then be recalculated based on your new body stats. "

	"Enter the number without units. The preferred units will be used automatically. "

	"For information on viewing or changing the preferred units, see 'help units'." },

	{ "height", 0, cmd_height, 0, 0 },

	{ "sex", 1, cmd_sex1,

	"Show sex multiplier or log a change in sex multiplier",

	"Shows you your last recorded sex multiplier. "

	"This is used to decide which variant of the Harris-Benedict equation "

	"to use to calculate your TDEE when data on percent body fat is unavailable. "

	"The sex multiplier will usually be either exactly 0 if you are a woman "

	"or exactly 1 if you are a man. However, if you are not cisgender, "

	"and you are currently taking hormones to transition into presenting "

	"as your true gender identity, the metabolic effects of the transition process "

	"might offset this multiplier and cause it to land somewhere in-between." },

	{ "sex", 0, cmd_sex, 0, 0 },

	{ "activity", 1, cmd_activity1,

	"Show current TDEE activity factor or log a change in TDEE activity factor",

	"Shows you your last recorded activity factor. "

	"If you fill in the blank, it will instead record a new activity factor. "

	"This is the ratio of your TDEE (total daily energy expenditure) "

	"to your BMR (basal metabolic rate). It gets its name "

	"from how strongly it's impacted by level of physical activity. "

	"Here are some common values for activity factor:\n"

	"* 1.2: Sedentary\n"

	"* 1.375: Light exercise 1-3 days/wk\n"

	"* 1.55: Moderate exercise 3-5 days/wk\n"

	"* 1.725: Hard exercise 6-7 days/wk\n"

	"* 1.9: Very hard exercise & physical job or 2x training\n"

	"In general, your activity factor should never drop to 1 or below, "

	"and should never rise to 2 or above. Keep this in mind when adjusting it. "

	"Also keep in mind that it's common for people "

	"to overestimate their activity factor." },

	{ "activity", 0, cmd_activity, 0, 0 },

	{ "pbf", 1, cmd_pbf1,

	"Show current percent body fat or log a change in percent body fat",

	"Shows you your last recorded percent body fat. "

	"If you fill in the blank, it will instead record a new percent body fat. "

	"Your percent body fat can be used to calculate your TDEE "

	"as an alternative to the Harris-Benedict equations. "

	"You don't need to record a percent body fat at all, "

	"but if you do, your TDEE will be more accurate. "

	"If you enter a value for this, don't add the percent sign." },

	{ "pbf", 0, cmd_pbf, 0, 0 },

	{ "tdee", 1, cmd_tdee1,

	"Show current TDEE or log a manual adjustment to TDEE",

	"Shows you your last calculated or entered TDEE. "

	"If you fill in the blank, it will instead record a manual adjustment to your TDEE. "

	"Enter the number without units. The preferred units will be used automatically. "

	"For information on viewing or changing the preferred units, see 'help units'." },

	{ "tdee", 0, cmd_tdee, 0, 0 },

	{ "goal", 1, cmd_goal1,

	"Show current goal rate of weight loss or log a change in goal rate of weight loss",

	"Shows you your last recorded goal rate of weight loss. "

	"If you fill in the blank, it will instead record a new goal rate of weight loss. "

	"The units are kg per week if you're using metric units, "

	"or lbs per week if you're using imperial units. "

	"Enter the number without units. The preferred units will be used automatically. "

	"For information on viewing or changing the preferred units, see 'help units'." },

	{ "goal", 0, cmd_goal, 0, 0 },

	{ "progress", 0, cmd_progress,

	"Show total weight lost",

	"Shows you the total weight you've lost since you started using the program, "

	"or since 4095 commits ago if you have more commits than that. "

	"Unfortunately the program cannot maintain data more than 4095 entries old." },

	{ "units", 1, cmd_units1,

	"Show or set preferred units",

	"Shows you whether you're using metric or imperial height and weight units. "

	"If you fill in the blank, it will instead record a new unit preference. "

	"Fill the blank with 'metric' for metric or 'imperial' for imperial "

	"(no quotes)." },

	{ "units", 0, cmd_units, 0, 0 },

	{ "save", 0, cmd_save,

	"Save without exiting",

	"Saves your changes to your personal data, but does not close the program." },

	{ "abort", 0, cmd_abort,

	"Exit without saving",

	"Discards all unsaved changes to your personal data. "

	"For example, if you accidentally log your calories wrong, "

	"you can use 'abort' to keep the log from being saved. "

	"On Unix-like systems, Ctrl+C does the same thing." },

	{ "exit", 0, cmd_exit,

	"Save and exit",

	"Saves your changes to your personal data and closes the program. "

	"On Unix-like systems, Ctrl+D does the same thing." },

	{ "reset", 0, cmd_reset,

	"Archive and reset your progress",

	"Renames your data file to a timestamped archive filename "

	"and exits the program. If/when you load the program up again, "

	"you'll be starting from scratch." }

};

void respond(const char *command, int argc, char *argv[], int quiet) {

	size_t i, c;

	for (i = 0, c = sizeof(commands) / sizeof(*commands); i < c; ++i)

		if (argc == commands[i].argc && !strcmp(command, commands[i].name)) {

			commands[i].implementation(argv, quiet);

			break;

		}

	if (i >= c) {

		if (quiet) fprintf(stderr,

			"calorieclock: Unknown command '%s' with %d arguments\n",

			command, argc);

		else fprintf(stderr,

			"No command with name '%s' and %d arguments.\n"

			"For a list of commands, issue the 'help' command.\n",

			command, argc);

	}

}

static void cmd_help(char *argv[], int quiet) {

	if (quiet) {

		puts("calorieclock, version " VERSION "\n"

			"Usage:\tcalorieclock\n"

			"\tcalorieclock [command] [argument] ...\n"

			"Commands:");

		for (size_t i = 0, c = sizeof(commands) / sizeof(*commands); i < c; ++i)

			if (commands[i].summary)

				printf("\t%s\n", commands[i].name);

		puts("For more information, type `calorieclock help ____',");

		puts("filling in the blank with the name of another command.");

		puts("Example: caloriecounter help help");

	}
	else for (size_t i = 0, c = sizeof(commands) / sizeof(*commands); i < c; ++i)

		if (commands[i].summary)

			printf("%s\t\t%s\n", commands[i].name, commands[i].summary);

}

static void cmd_help1(char *argv[], int quiet) {

	for (size_t i = 0, c = sizeof(commands) / sizeof(*commands); i < c; ++i)

		if (!strcmp(argv[0], commands[i].name)) {

			printf("%s", commands[i].name);

			for (int j = 0; j < commands[i].argc; ++j)

				printf(" ____");

			puts("");

		}

	for (size_t i = 0, c = sizeof(commands) / sizeof(*commands); i < c; ++i)

		if (commands[i].documentation && !strcmp(argv[0], commands[i].name))

			puts(commands[i].documentation);

}