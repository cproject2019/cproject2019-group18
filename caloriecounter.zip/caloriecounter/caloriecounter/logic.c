#include <math.h>

#include <stddef.h>

#include <stdio.h>

#include <time.h>

#include "logic.h"

#include "userdata.h"

#define SECONDS_IN_YEAR (31557600.0)

#define SECONDS_IN_DAY (84600.0)

#define CALORIES_IN_KG (7716.17)

#define GENERIC_RECOMMENDATION (2000.0)

static double calculate_bmr(

	double weight,

	double height,

	double gendar,

	double percentbodyfat,

	time_t dateofbirth) {

	time_t now = time(0);

	// units are kg and cm

	if (!weight) return 0;

	double age = (now - dateofbirth) / SECONDS_IN_YEAR;

	double female_bmr = 655 + 9.6*weight + 1.8*height + 4.7*age;

	double male_bmr = 660 + 13.7*weight + 5 * height + 6.8*age;

	double mean_sex_based_bmr = female_bmr*(1 - gendar) + male_bmr*gendar;

	double lbm_based_bmr = 370 + 21.6*(1 - percentbodyfat)*weight;

	if (height && percentbodyfat && dateofbirth)

		return (mean_sex_based_bmr + lbm_based_bmr) / 2;

	if (height && dateofbirth) return mean_sex_based_bmr;

	if (percentbodyfat) return lbm_based_bmr;

	return 0;

}

static double calculate_tdee(

	double bmr,

	double activitylevel) {

	if (activitylevel) return bmr*activitylevel;

	return bmr*1.2; 

}

static void update_calorieallowance(struct userdata *userdata) {

	userdata->calorieallowance +=

		(time(0) - userdata->lastupdate)

		* (userdata->tdee - userdata->goalweeklydelta*CALORIES_IN_KG / 7.0) / SECONDS_IN_DAY;

}

static int update_tdee_fromweight(struct userdata *userdata, double weight) {

	const struct userdata *all_userdata = get_all_userdata();

	size_t i;

	for (i = 0; all_userdata[i].lastupdate; ++i);

	--i;

	double initial_weight = all_userdata[i].weight;

	time_t initial_time = all_userdata[i].lastupdate;

	double cals_consumed = 0;

	double cals_last = 0;

	for (; i != (size_t)-1; --i) {

		if (all_userdata[i].calorieallowance < cals_last)

			cals_consumed += cals_last - all_userdata[i].calorieallowance;

		cals_last = all_userdata[i].calorieallowance;

	}

	double final_weight = weight;

	time_t final_time = time(0);

	if (final_time - initial_time >= SECONDS_IN_DAY * 7) {

		userdata->tdee =

			((initial_weight - final_weight)*CALORIES_IN_KG + cals_consumed)

			* SECONDS_IN_DAY / (final_time - initial_time);

		return 1;

	}

	return 0;

}

static void update_tdee_fromstats(struct userdata *userdata) {

	double newtdee = calculate_tdee(

		calculate_bmr(

			userdata->weight,

			userdata->height,

			userdata->gendar,

			userdata->percentbodyfat,

			userdata->dateofbirth),

		userdata->activitylevel);

	if (newtdee) userdata->tdee = newtdee;

}

void do_initial_setup(

	double weight,

	double height,

	double sexfactor,

	double activitylevel,

	double percentbodyfat,

	double goalweeklydelta,

	time_t dateofbirth) {

	struct userdata *userdata = get_userdata();

	*userdata = (struct userdata) {

		.weight = weight,

			.height = height,

			.gendar = sexfactor,

			.activitylevel = activitylevel,

			.percentbodyfat = percentbodyfat,

			.goalweeklydelta = goalweeklydelta,

			.dateofbirth = dateofbirth

	};

	update_tdee_fromstats(userdata);

	if (!userdata->tdee) {

		fputs("WARN: Not enough data to calculate TDEE. "

			"Defaulting to 2000 cals/day.\n"

			"For a more accurate TDEE, "

			"please provide either your weight and percent body fat, "

			"or your weight, height, gender, and date of birth.\n"

			"(For information on what commands to use to provide this data, "

			"type 'help'.)",

			stderr);

		userdata->tdee = GENERIC_RECOMMENDATION;

	}

	commit_userdata();

}

void do_initial_setup_known_tdee(double tdee, double goalweeklydelta) {

	*(get_userdata()) = (struct userdata) {

		.tdee = tdee,

			.goalweeklydelta = goalweeklydelta

	};

	commit_userdata();

}

void update_weight(double weight) {

	struct userdata *userdata = get_userdata();

	userdata->weight = weight;

	if (!update_tdee_fromweight(userdata, weight))

		update_tdee_fromstats(userdata);

	update_calorieallowance(userdata);

	commit_userdata();

}

void update_height(double height) {

	struct userdata *userdata = get_userdata();

	userdata->height = height;

	update_tdee_fromstats(userdata);

	update_calorieallowance(userdata);

	commit_userdata();

}

void update_sexfactor(double sexfactor) {

	struct userdata *userdata = get_userdata();

	userdata->gendar = sexfactor;

	update_tdee_fromstats(userdata);

	update_calorieallowance(userdata);

	commit_userdata();

}

void update_activitylevel(double activitylevel) {

	struct userdata *userdata = get_userdata();

	userdata->activitylevel = activitylevel;

	update_tdee_fromstats(userdata);

	update_calorieallowance(userdata);

	commit_userdata();

}

void update_percentbodyfat(double percentbodyfat) {

	struct userdata *userdata = get_userdata();

	userdata->percentbodyfat = percentbodyfat;

	update_tdee_fromstats(userdata);

	update_calorieallowance(userdata);

	commit_userdata();

}

void update_tdee(double tdee) {

	struct userdata *userdata = get_userdata();

	userdata->tdee = tdee;

	update_calorieallowance(userdata);

	commit_userdata();

}

void update_goalweeklydelta(double goalweeklydelta) {

	struct userdata *userdata = get_userdata();

	userdata->goalweeklydelta = goalweeklydelta;

	update_calorieallowance(userdata);

	commit_userdata();

}

void log_calories(double calories) {

	struct userdata *userdata = get_userdata();

	update_calorieallowance(userdata);

	userdata->calorieallowance -= calories;

	commit_userdata();

}

double update_justcheckingcalories(void) {

	struct userdata *userdata = get_userdata();

	update_calorieallowance(userdata);

	commit_userdata();

	return userdata->calorieallowance;

}