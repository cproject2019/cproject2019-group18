#pragma once

struct userdata {

	double calorieallowance;

	double weight;

	double height;

	double gendar;

	double activitylevel;

	double percentbodyfat;

	double tdee;

	double goalweeklydelta;

	long long int dateofbirth;

	long long int lastupdate;

	int useimperialunits;

};

void load_userdata(void);

struct userdata *get_userdata(void);

void commit_userdata(void);

void save_userdata(void);

const struct userdata *get_all_userdata();

void fresh_start(void); 
