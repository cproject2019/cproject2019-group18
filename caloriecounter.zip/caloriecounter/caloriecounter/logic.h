#pragma once
#include <time.h>
#include "userdata.h"

void do_initial_setup(

	double weight,

	double height,

	double gendar,

	double activitylevel,

	double percentbodyfat,

	double goalweeklydelta,

	time_t dateofbirth);

void do_initial_setup_known_tdee(

	double tdee,

	double goalweeklydelta);

void update_weight(double);

void update_height(double);

void update_gendar(double);

void update_activitylevel(double);

void update_percentbodyfat(double);

void update_tdee(double);

void update_goalweeklydelta(double);

void log_calories(double);

double update_checkingcalories(void);

