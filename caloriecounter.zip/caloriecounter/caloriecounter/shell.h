#pragma once

void shellinit(void);

void checkunits(void);

void respond(const char *command, int argc, char *argv[], int quiet);
